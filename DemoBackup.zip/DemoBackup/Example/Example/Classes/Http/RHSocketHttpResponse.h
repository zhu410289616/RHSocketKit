//
//  RHSocketHttpResponse.h
//  RHSocketKitDemo
//
//  Created by zhuruhong on 16/2/16.
//  Copyright © 2016年 zhuruhong. All rights reserved.
//

#import "RHSocketPacketContext.h"

@interface RHSocketHttpResponse : RHSocketPacketResponse

@end
