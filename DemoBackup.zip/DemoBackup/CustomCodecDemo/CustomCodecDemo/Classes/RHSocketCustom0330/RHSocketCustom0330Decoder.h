//
//  RHSocketCustom0330Decoder.h
//  RHSocketCustomCodecDemo
//
//  Created by zhuruhong on 16/3/30.
//  Copyright © 2016年 zhuruhong. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RHSocketCodecProtocol.h"

@interface RHSocketCustom0330Decoder : NSObject <RHSocketDecoderProtocol>

@end
